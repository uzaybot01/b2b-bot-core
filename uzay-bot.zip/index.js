require('dotenv').config();
const { Client, GatewayIntentBits, Events, EmbedBuilder } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessages
  ]
});

client.once(Events.ClientReady, () => {
  console.log(`Bot başarıyla aktif edildi: ${client.user.tag}`);
});

client.on(Events.MessageCreate, async (message) => {
  // Sadece yöneticiler komut kullanabilir
  if (!message.member || !message.member.permissions.has('Administrator')) return;

  // DM GÖNDERME KOMUTU (!bildiri @Rol Mesajınız...)
  if (message.content.startsWith('!bildiri')) {
    
    // 1. Yönetici komutun içinde bir rol etiketlemiş mi kontrol et
    const hedefRol = message.mentions.roles.first();
    
    if (!hedefRol) {
      return message.reply('Lütfen kime göndereceğinizi seçmek için bir rol etiketleyin.\nÖrnek kullanım: `!bildiri @yesilsancak Herkese merhaba!`');
    }

    // 2. Mesaj metnini temizle (komutu ve rol etiketini metinden çıkar, sadece senin yazdığın mesaj kalsın)
    let mesajMetni = message.content
      .replace('!bildiri', '')
      .replace(`<@&${hedefRol.id}>`, '')
      .trim();

    // 3. Görsel eklentisi var mı kontrol et
    let eklentiUrl = null;
    if (message.attachments.size > 0) {
      eklentiUrl = message.attachments.first().url;
    }

    if (!mesajMetni && !eklentiUrl) {
      return message.reply('Lütfen gönderilecek metni yazın veya bir görsel ekleyin.');
    }
    
    // 4. Sunucudaki üyeleri tara ve adminin etiketlediği role sahip olanları bul
    await message.guild.members.fetch();
    const hedefUyeler = message.guild.members.cache.filter(m => m.roles.cache.has(hedefRol.id) && !m.user.bot);

    if (hedefUyeler.size === 0) {
      return message.reply(`Etiketlediğiniz **${hedefRol.name}** rolüne sahip kimse bulunamadı.`);
    }

    await message.reply(`Bildiri **${hedefRol.name}** rolündeki ${hedefUyeler.size} üyeye SMS formatında gönderilmeye başlanıyor...`);

    let basarili = 0;
    let basarisiz = 0;

    // 5. Üyelere sırayla kurumsal Yeşilsancak mesajı at ve aralarda bekle
    for (const [id, uye] of hedefUyeler) {
      try {
        const kampanyaEmbed = new EmbedBuilder()
          .setColor('#2ecc71')
          .setTitle('🟢 Yeşilsancak Özel Bildiri')
          .setThumbnail(client.user.displayAvatarURL())
          .setFooter({ text: 'Yeşilsancak Topluluğu' })
          .setTimestamp();

        if (mesajMetni) {
          kampanyaEmbed.setDescription(mesajMetni);
        }

        if (eklentiUrl) {
          kampanyaEmbed.setImage(eklentiUrl);
        }

        await uye.send({ embeds: [kampanyaEmbed] });
        basarili++;
        
        await new Promise(resolve => setTimeout(resolve, 2500));
      } catch (error) {
        basarisiz++;
      }
    }

    await message.channel.send(`✅ **Gönderim Tamamlandı!**\nHedef Kitle: **${hedefRol.name}**\nBaşarıyla iletilen: ${basarili}\nİletilemeyen (DM'i Kapalı Olanlar): ${basarisiz}`);
  }
});

client.login(process.env.BOT_TOKEN);